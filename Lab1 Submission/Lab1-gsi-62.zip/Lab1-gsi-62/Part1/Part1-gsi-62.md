#Part 1 - Commands and Tutorial  
1. Easiest Part
    * The easiest part of Unix Tutorial was that all the information(commands) were readily avaliable
    * The easiest part of OpenVim Tutorial was that it was quite interactive.
    * The easiest part of Markdown Tutorial was that the way the tutorial is desined is to practice topics which made learning syntax quite simple.
2. Hardest Part
    * The hardest part of Unix Tutorial was that there was no hands-on material, it was just text.
    * The hardest part of OpenVim Tutorial was they background color of screen(purple), which was very difficult to watch.
    * The hardest part of Markdown Tutorial was that there was no "show answer" for the questions.
3. Lessons Learnt
    * Unix Tutorial: It was a good revisions on UNIX commands and syntax of some of the commands.
    * OpenVim Tutorial: Learnt couple of new tricks about vi editor.
    * Markdown Tutorial: This was a totally new concept, so the tutorial was my starting point for Markdown language.